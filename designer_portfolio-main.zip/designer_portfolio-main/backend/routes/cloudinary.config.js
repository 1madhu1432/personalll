import { v2 as cloudinary } from "cloudinary";

cloudinary.config({
    cloud_name: "duvxuqszv",
    api_key: "323945485738298",
    api_secret: "R8rDWidmRWB9UWFoUNHEeAc7zGE",
});

export default cloudinary;